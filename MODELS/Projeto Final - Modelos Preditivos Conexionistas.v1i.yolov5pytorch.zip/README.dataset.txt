# Projeto Final - Modelos Preditivos Conexionistas > 2022-08-09 10:14am
https://universe.roboflow.com/object-detection/projeto-final---modelos-preditivos-conexionistas

Provided by Roboflow
License: CC BY 4.0

